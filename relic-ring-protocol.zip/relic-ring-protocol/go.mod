module github.com/launch26/relic-ring-protocol

go 1.23.0

require github.com/wailsapp/wails/v2 v2.12.0
