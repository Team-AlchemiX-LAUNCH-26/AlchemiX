import type { Route, Snapshot } from '../types';

export function UniverseMap({snapshot,route}:{snapshot:Snapshot;route?:Route}){
  const width=760,height=470,pad=55;
  const xs=snapshot.planets.map(p=>p.x),ys=snapshot.planets.map(p=>p.y);
  const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
  const point=(x:number,y:number)=>({x:pad+(x-minX)/(maxX-minX||1)*(width-pad*2),y:height-pad-(y-minY)/(maxY-minY||1)*(height-pad*2)});
  const status=new Map(snapshot.planet_status.map(s=>[s.id,s]));
  const activeEdges=new Set<string>();
  route?.path.slice(0,-1).forEach((id,i)=>activeEdges.add([id,route.path[i+1]].sort().join('::')));
  return <svg className="universe-map" viewBox={`0 0 ${width} ${height}`} role="img" aria-label="Zeta-26 universe map">
    <defs><filter id="glow"><feGaussianBlur stdDeviation="4" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
    {snapshot.links.map(link=>{const a=snapshot.planets.find(p=>p.id===link.a)!,b=snapshot.planets.find(p=>p.id===link.b)!;const pa=point(a.x,a.y),pb=point(b.x,b.y);const active=activeEdges.has([link.a,link.b].sort().join('::'));return <line key={`${link.a}-${link.b}`} x1={pa.x} y1={pa.y} x2={pb.x} y2={pb.y} className={active?'link active-link':'link'}/>})}
    {snapshot.planets.map((p,i)=>{const pt=point(p.x,p.y);const available=status.get(p.id)?.available??false;const inRoute=route?.path.includes(p.id);return <g key={p.id} transform={`translate(${pt.x},${pt.y})`} className="planet-group">
      <circle r={inRoute?21:17} className={`planet planet-${i%6} ${available?'':'failed'} ${inRoute?'route-planet':''}`} filter={inRoute?'url(#glow)':undefined}/>
      <circle r={27} className="planet-ring" strokeDasharray={`${Math.max(4,p.active_towers)} 5`}/>
      <text y={43} textAnchor="middle" className="planet-name">{p.id}</text><text y={58} textAnchor="middle" className="planet-meta">B{p.codex} · T{p.active_towers}</text>
    </g>})}
  </svg>
}
