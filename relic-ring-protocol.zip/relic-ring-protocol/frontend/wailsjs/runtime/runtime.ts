declare global { interface Window { runtime?:{ EventsOn?:(name:string,cb:(data:unknown)=>void)=>()=>void } } }
export function EventsOn(name:string, callback:(data:unknown)=>void):()=>void { return window.runtime?.EventsOn?.(name,callback) ?? (()=>{}); }
