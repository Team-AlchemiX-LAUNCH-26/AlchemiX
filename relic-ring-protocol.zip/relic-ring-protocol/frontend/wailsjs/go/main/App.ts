import type { TransmissionResult, UniverseResponse } from '../../../src/types';

declare global { interface Window { go:{ main:{ App:{ GetUniverse:()=>Promise<UniverseResponse>; StartTransmission:(req:{origin_id:string;destination_id:string;payload:string})=>Promise<TransmissionResult>; DisableNode:(id:string)=>Promise<void>; EnableNode:(id:string)=>Promise<void>; DisableLink:(a:string,b:string)=>Promise<void>; EnableLink:(a:string,b:string)=>Promise<void>; ResetNetwork:()=>Promise<void> }}}}}
export const GetUniverse=()=>window.go.main.App.GetUniverse();
export const StartTransmission=(req:{origin_id:string;destination_id:string;payload:string})=>window.go.main.App.StartTransmission(req);
export const DisableNode=(id:string)=>window.go.main.App.DisableNode(id);
export const EnableNode=(id:string)=>window.go.main.App.EnableNode(id);
export const DisableLink=(a:string,b:string)=>window.go.main.App.DisableLink(a,b);
export const EnableLink=(a:string,b:string)=>window.go.main.App.EnableLink(a,b);
export const ResetNetwork=()=>window.go.main.App.ResetNetwork();
