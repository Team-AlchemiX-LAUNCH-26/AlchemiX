package latency

import (
	"github.com/launch26/relic-ring-protocol/internal/domain"
	"github.com/launch26/relic-ring-protocol/internal/geometry"
)

func PlanetTransit(p domain.Planet, entryTower, exitTower int, metadata domain.UniverseMetadata) domain.PlanetTransitBreakdown {
	segments, distinct := geometry.ShortestRingSegments(entryTower, exitTower, p.ActiveTowers)
	fiber := FiberSeconds(p.RadiusKM, p.ActiveTowers, segments, metadata.FiberSpeedFraction, metadata.SpeedOfLightKMS)
	tower := TowerDelaySeconds(distinct, metadata.TowerProcessingDelayMS)
	return domain.PlanetTransitBreakdown{
		PlanetID:       p.ID,
		EntryTower:     entryTower,
		ExitTower:      exitTower,
		Segments:       segments,
		DistinctTowers: distinct,
		FiberSeconds:   fiber,
		TowerSeconds:   tower,
		TotalSeconds:   fiber + tower,
	}
}
