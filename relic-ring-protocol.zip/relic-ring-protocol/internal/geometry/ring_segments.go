package geometry

func ShortestRingSegments(entryTower, exitTower, towerCount int) (segments, distinctTowers int) {
	if towerCount <= 0 {
		return 0, 0
	}
	diff := entryTower - exitTower
	if diff < 0 {
		diff = -diff
	}
	other := towerCount - diff
	if other < diff {
		diff = other
	}
	if diff == 0 {
		return 0, 1
	}
	return diff, diff + 1
}
