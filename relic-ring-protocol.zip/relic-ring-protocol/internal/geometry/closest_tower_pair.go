package geometry

import (
	"fmt"
	"math"

	"github.com/launch26/relic-ring-protocol/internal/domain"
)

func ClosestTowerPair(from, to domain.Planet, scale float64) (domain.TowerPair, error) {
	fromTowers := GenerateTowers(from, scale)
	toTowers := GenerateTowers(to, scale)
	if len(fromTowers) == 0 || len(toTowers) == 0 {
		return domain.TowerPair{}, fmt.Errorf("cannot find tower pair for planets with no towers")
	}

	best := domain.TowerPair{Distance: math.Inf(1)}
	for _, a := range fromTowers {
		for _, b := range toTowers {
			d := math.Hypot(b.XKM-a.XKM, b.YKM-a.YKM)
			if d < best.Distance-1e-9 || (math.Abs(d-best.Distance) <= 1e-9 && (a.Index < best.FromTower.Index || (a.Index == best.FromTower.Index && b.Index < best.ToTower.Index))) {
				best = domain.TowerPair{FromTower: a, ToTower: b, Distance: d}
			}
		}
	}
	return best, nil
}
