package domain

type Tower struct {
	Index        int     `json:"index"`
	AngleDegrees float64 `json:"angle_degrees"`
	XKM          float64 `json:"x_km"`
	YKM          float64 `json:"y_km"`
}

type TowerPair struct {
	FromTower Tower   `json:"from_tower"`
	ToTower   Tower   `json:"to_tower"`
	Distance  float64 `json:"distance_km"`
}
