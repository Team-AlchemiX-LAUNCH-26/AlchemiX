package resilience

import "sync"

type State struct {
	mu             sync.RWMutex
	healthy        map[string]bool
	manualDisabled map[string]bool
	disabledLinks  map[string]bool
	failures       map[string]int
	threshold      int
}

func NewState(planetIDs []string, threshold int) *State {
	if threshold < 1 {
		threshold = 1
	}
	s := &State{
		healthy:        make(map[string]bool, len(planetIDs)),
		manualDisabled: make(map[string]bool),
		disabledLinks:  make(map[string]bool),
		failures:       make(map[string]int),
		threshold:      threshold,
	}
	for _, id := range planetIDs {
		s.healthy[id] = true
	}
	return s
}

func (s *State) RecordHealth(id string, healthy bool) (changed bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	old := s.healthy[id]
	if healthy {
		s.failures[id] = 0
		s.healthy[id] = true
	} else {
		s.failures[id]++
		if s.failures[id] >= s.threshold {
			s.healthy[id] = false
		}
	}
	return old != s.healthy[id]
}

func (s *State) SetHealth(id string, healthy bool) (changed bool) {
	s.mu.Lock()
	defer s.mu.Unlock()
	old := s.healthy[id]
	s.healthy[id] = healthy
	if healthy {
		s.failures[id] = 0
	} else {
		s.failures[id] = s.threshold
	}
	return old != healthy
}

func (s *State) DisableNode(id string) { s.mu.Lock(); s.manualDisabled[id] = true; s.mu.Unlock() }
func (s *State) EnableNode(id string)  { s.mu.Lock(); delete(s.manualDisabled, id); s.mu.Unlock() }
func (s *State) DisableLink(id string) { s.mu.Lock(); s.disabledLinks[id] = true; s.mu.Unlock() }
func (s *State) EnableLink(id string)  { s.mu.Lock(); delete(s.disabledLinks, id); s.mu.Unlock() }

func (s *State) Reset() {
	s.mu.Lock()
	defer s.mu.Unlock()
	s.manualDisabled = make(map[string]bool)
	s.disabledLinks = make(map[string]bool)
	for id := range s.healthy {
		s.healthy[id] = true
		s.failures[id] = 0
	}
}

func (s *State) Snapshot() (healthy, manual, links map[string]bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	healthy = clone(s.healthy)
	manual = clone(s.manualDisabled)
	links = clone(s.disabledLinks)
	return
}

func clone(in map[string]bool) map[string]bool {
	out := make(map[string]bool, len(in))
	for k, v := range in {
		out[k] = v
	}
	return out
}
