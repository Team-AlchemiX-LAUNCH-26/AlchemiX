package routing

import (
	"fmt"
	"sort"

	"github.com/launch26/relic-ring-protocol/internal/domain"
)

type Graph struct {
	Metadata  domain.UniverseMetadata
	Planets   map[string]domain.Planet
	Adjacency map[string][]domain.Link
	Links     []domain.Link
}

func (g *Graph) Neighbors(id string) []domain.Link {
	return g.Adjacency[id]
}

func (g *Graph) Link(from, to string) (domain.Link, error) {
	for _, l := range g.Adjacency[from] {
		if other, ok := l.Other(from); ok && other == to {
			return l, nil
		}
	}
	return domain.Link{}, fmt.Errorf("no active link between %s and %s", from, to)
}

func (g *Graph) SortedPlanetIDs() []string {
	ids := make([]string, 0, len(g.Planets))
	for id := range g.Planets {
		ids = append(ids, id)
	}
	sort.Strings(ids)
	return ids
}
