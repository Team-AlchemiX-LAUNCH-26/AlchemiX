package routing

import (
	"sort"

	"github.com/launch26/relic-ring-protocol/internal/domain"
	"github.com/launch26/relic-ring-protocol/internal/geometry"
)

func LinkID(a, b string) string {
	pair := []string{a, b}
	sort.Strings(pair)
	return pair[0] + "::" + pair[1]
}

func BuildLink(a, b domain.Planet, metadata domain.UniverseMetadata) (domain.Link, bool, error) {
	voidDistance, err := geometry.VoidDistanceKM(a, b, metadata.CoordinateScaleUnitKM)
	if err != nil {
		return domain.Link{}, false, err
	}
	if voidDistance > metadata.MaxVoidHopDistanceKM {
		return domain.Link{}, false, nil
	}
	pair, err := geometry.ClosestTowerPair(a, b, metadata.CoordinateScaleUnitKM)
	if err != nil {
		return domain.Link{}, false, err
	}
	return domain.Link{
		A:              a.ID,
		B:              b.ID,
		VoidDistanceKM: voidDistance,
		ATower:         pair.FromTower.Index,
		BTower:         pair.ToTower.Index,
	}, true, nil
}
