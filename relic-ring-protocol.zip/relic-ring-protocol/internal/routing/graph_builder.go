package routing

import (
	"fmt"
	"sort"

	"github.com/launch26/relic-ring-protocol/internal/domain"
)

func BuildGraph(cfg domain.UniverseConfig, unavailableNodes, disabledLinks map[string]bool) (*Graph, error) {
	g := &Graph{
		Metadata:  cfg.Metadata,
		Planets:   make(map[string]domain.Planet),
		Adjacency: make(map[string][]domain.Link),
	}
	for _, p := range cfg.Nodes {
		if unavailableNodes[p.ID] {
			continue
		}
		g.Planets[p.ID] = p
		g.Adjacency[p.ID] = nil
	}

	for i := 0; i < len(cfg.Nodes); i++ {
		a := cfg.Nodes[i]
		if unavailableNodes[a.ID] {
			continue
		}
		for j := i + 1; j < len(cfg.Nodes); j++ {
			b := cfg.Nodes[j]
			if unavailableNodes[b.ID] || disabledLinks[LinkID(a.ID, b.ID)] {
				continue
			}
			link, valid, err := BuildLink(a, b, cfg.Metadata)
			if err != nil {
				return nil, fmt.Errorf("build link %s-%s: %w", a.ID, b.ID, err)
			}
			if !valid {
				continue
			}
			g.Links = append(g.Links, link)
			g.Adjacency[a.ID] = append(g.Adjacency[a.ID], link)
			g.Adjacency[b.ID] = append(g.Adjacency[b.ID], link)
		}
	}
	for id := range g.Adjacency {
		sort.Slice(g.Adjacency[id], func(i, j int) bool {
			a, _ := g.Adjacency[id][i].Other(id)
			b, _ := g.Adjacency[id][j].Other(id)
			return a < b
		})
	}
	return g, nil
}
